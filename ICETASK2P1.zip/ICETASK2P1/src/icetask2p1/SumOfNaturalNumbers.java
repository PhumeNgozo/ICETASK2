/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask2p1;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class SumOfNaturalNumbers {
  public static void main(String[] args){
   Scanner scanner = new Scanner(System.in);

    System.out.println("Enter a positive integer");
    int n = scanner.nextInt();
    
    int sum = 0;
    for(int i = 1; i<= n; i++)
{
     sum += i;
   }
    
   System.out.println("The sum of first" + n + "natural numbers is:" + sum);
  }    
}
