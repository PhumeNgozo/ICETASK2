/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask2p1;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class IfElse {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a year");
        int year = scanner.nextInt();
        if(year % 4 == 0);
        if(year % 100 ==0);
        if(year %400 ==0);
        
    System.out.println(year + "is a leap year");
              
    
    System.out.println(year + "is not a leap year");
           
         scanner.close();
           
           
}
}
