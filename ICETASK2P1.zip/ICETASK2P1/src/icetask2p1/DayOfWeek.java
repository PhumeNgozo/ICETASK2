/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask2p1;
import java.util.Scanner;


/**
 *
 * @author RC_Student_lab
 */
public class DayOfWeek {
     public static void main (int[] args){  
         Scanner scanner = new Scanner(System.in);
         
         System.out.println("Enter a number from 1 to 7:");
         int dayNumber = scanner.nextInt();
         
         
         String dayName;
         switch (dayNumber){
             case 1:
                 dayName = "Monday";
                 break;
             case 2:
                 dayName = "Tuesday";
                 break;
             case 3: 
                 dayName = "Wednesday";
                 break;
             case 4:
                 dayName = "Thursday";
                 break;
             case 5:
                 dayName = "Friday";
                 break;
             case 6:
                 dayName = "Friday";
                 break;
             case 7:
                 dayName = "Sunday";
             default:
                 dayName = "Invalid day number";       
         }
         
         System.out.println("The day of the week is:" + dayName);
        
         
         
         
     }
}
